import React from 'react';
import "./Header.css"
import { Badge, Container, Dropdown, FormControl, Navbar,Nav, Button } from 'react-bootstrap'
import DropdownToggle from 'react-bootstrap/esm/DropdownToggle';
import DropdownMenu from 'react-bootstrap/esm/DropdownMenu';
import { FaShoppingCart } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <Navbar bg="white" style={{height: 80}} >
        <Container>
            <Navbar.Brand>
                <Link to="/" className='logo'><b>MegaMart</b></Link>
            </Navbar.Brand>
      <Dropdown>
      <Dropdown.Toggle className='all' variant="Info" id="dropdown-basic" style={{minWidth:20}}>
        All
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
      </Dropdown.Menu>
     </Dropdown>
            <Navbar.Text className='search'>
               <FormControl style={{width:500}} placeholder='Search here' className="m-auto" />
               
            </Navbar.Text>
           <span ><Button className='search2'>Search</Button></span>
            <Nav>
              <Dropdown alignRight>
               <DropdownToggle>
               <FaShoppingCart color="white" fontSize="25px"/>
                <Badge>{10}</Badge>
               </DropdownToggle>

               <DropdownMenu style={{minWidth: 370}}>
                <span style={{padding:10}}>Cart is empty</span>
               </DropdownMenu>
              </Dropdown>
            </Nav>
        </Container>
    </Navbar>
  )
}

export default Header