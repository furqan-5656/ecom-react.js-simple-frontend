import React, { useEffect } from 'react';
import "./Home.css";
//import Card from "../components/card/Card";
import Records from '../../src/data1.json';
import { Card,Button, FormControl, Col } from 'react-bootstrap';
import "./card/Card.css";
import {useState} from 'react';

// navbar 

import "./Header.css"
import { Badge, Container, Dropdown, Navbar,Nav } from 'react-bootstrap'
import DropdownToggle from 'react-bootstrap/esm/DropdownToggle';
import DropdownMenu from 'react-bootstrap/esm/DropdownMenu';
import { FaShoppingCart } from 'react-icons/fa';
import { Link } from 'react-router-dom';


const Home = () => {
  //use state for searching part
  const [searchTerm, setSearchTerm] = useState("");
  //use state for add to cart value
  const [count,setCount]=useState(true);
//for storing cart count and data presistant
  useEffect(()=>{
    const data= window.localStorage.getItem('MY_data_store');
    if(data !==null) setCount(JSON.parse(data))
  },[])

   useEffect(()=> {
    window.localStorage.setItem('MY_data_store',JSON.stringify(count))
   },[count])
  return (
    <div>
      
      <Navbar bg="white" style={{height: 80}} >
        <Container>
            <Navbar.Brand>
                <Link to="/" className='logo'><b style={{color:"rgb(63, 123, 253)"}}>MegaMart</b></Link>
            </Navbar.Brand>
      <Dropdown>
      <Dropdown.Toggle className='all' variant="Info" id="dropdown-basic" style={{minWidth:20}}>
        All
      </Dropdown.Toggle>

      <Dropdown.Menu>
        
        <Dropdown.Item href="">Jacket</Dropdown.Item>
        <Dropdown.Item href="#/action-2">Games</Dropdown.Item>
        <Dropdown.Item href="#/action-2">Men's</Dropdown.Item>
        <Dropdown.Item href="#/action-3">Help</Dropdown.Item>
        
      </Dropdown.Menu>
     </Dropdown>
            <Navbar.Text className='search'>
            <FormControl style={{width:500}} id="searchInput" type="text" placeholder="Search here..." onChange={(event) => {
            setSearchTerm(event.target.value);
          }} />
               
            </Navbar.Text>
            
            
            <Nav>
              
              <Dropdown alignRight >
               <DropdownToggle>
               <FaShoppingCart color="white" fontSize="25px"/>
                <Badge>{count}</Badge>
               </DropdownToggle>

               <DropdownMenu style={{minWidth: 370}}>
                <span style={{padding:10}}>Cart contain {count} Items</span>
               </DropdownMenu>
              </Dropdown>
            </Nav>
            
        </Container>
    </Navbar>
        <h1>Results</h1>
        <div className='cards'>
        
          {

            Records

            .filter((record) => {
              if(searchTerm == ""){
                return record;
              }else if(record.title.toLowerCase().includes(searchTerm.toLowerCase())){
                return record;
              }
            })
            
            
            .map(record=>{
              return(




                //cards 
                <Card style={{ width: '18rem' }} className='allacard' key={record.id}>
                  <Card.Img className='m-auto' variant="top" src={record.image} style={{width: 200, height: 200}} />
                      <Card.Body>
                           <Card.Title>{record.title}</Card.Title>
                            <Card.Text><p>{record.description}</p>
        </Card.Text>
        <p><b>Ratings:</b>{record.rating.rate}</p><br/>
        <p><b>Rs:</b>{record.price}</p>
        <p style={{fontSize:10}}>{record.category}</p>
        <Button variant="primary" className='m-auto ' onClick={()=>setCount(count + 1)} >Add to Cart</Button>

      </Card.Body>
      
                 </Card>
              )
            }
            )
          }
        </div>
    </div>
  )
}

export default Home