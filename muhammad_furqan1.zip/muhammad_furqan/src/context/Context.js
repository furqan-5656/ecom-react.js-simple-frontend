import React from 'react'
import { createContext } from 'react';
const cart = createContext();

const Context = ({childern}) => {
  return (
    <cart.Provider>{childern}</cart.Provider>
  )
}

export default Context